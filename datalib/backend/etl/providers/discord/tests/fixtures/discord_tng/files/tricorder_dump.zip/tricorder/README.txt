Chief engineer's note: these readings are from the aft array only.
The forward array is still pointed at whatever Q left there.
